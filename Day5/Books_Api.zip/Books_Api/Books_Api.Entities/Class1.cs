﻿namespace Books_Api.Entities
{
    public class Class1
    {

    }
}
