﻿namespace Books_Api.DTO
{
    public class LoginResDto
    {
        public string Email { get; set; }
        public string Role { get; set; }
        public string Name { get; set; }

        public string Token { get; set; }
    }
}
